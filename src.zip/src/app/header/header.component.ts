import {Component, EventEmitter, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  private privateImage: string;
  @Output() toggleSide = new EventEmitter();
  constructor() { }
  ngOnInit() {
    this.privateImage = 'https://assets.zapnito.com/assets/medium-default-avatar.png';
  }
  OpenSideNav(val: boolean) {
    this.toggleSide.emit(val);
  }
}
