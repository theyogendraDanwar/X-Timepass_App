import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatitem',
  templateUrl: './chatitem.component.html',
  styleUrls: ['./chatitem.component.css']
})
export class ChatitemComponent implements OnInit {
  private ImageSrc: string;
  constructor() { }
  ngOnInit() {
    this.ImageSrc = 'https://assets.zapnito.com/assets/medium-default-avatar.png';
  }
}
