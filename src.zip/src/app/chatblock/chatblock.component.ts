import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatblock',
  templateUrl: './chatblock.component.html',
  styleUrls: ['./chatblock.component.css']
})
export class ChatblockComponent implements OnInit {

	public people = 10;
  constructor() { }

  ngOnInit() {
  }

}
